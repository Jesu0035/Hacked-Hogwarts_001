'use strict';
window.addEventListener('DomContentLoaded', start);
const allStudents = [];
const settings = {
  filterBy: "all",
  sortBy: "firstname",
  sortDir: "asc",
};
const  Student = {
  firstName:'',
  midleName:'',
  lastName: '',
  gender:'',
  house: ''
};

 fetch('https://petlatkea.dk/2021/hogwarts/students.json')
.then(function(response){
    console.log(response)
    return response.json(); 
})
.then(function(data){
console.log(data);
    dataReceived(data);
})
function dataReceived(students){
 students.forEach(student => {
   console.log(student);
   showList(student);
   
 });
       
}      
function showList(student){
    console.log(student);
const template = document.querySelector('#myTemplate').content;
const copy = template.cloneNode(true);
copy.querySelector('.name').textContent = student.fullname;
copy.querySelector('.gender').textContent = student.gender;
copy.querySelector('.house').textContent = student.house;

const parentElement = document.querySelector('section#students');

document.querySelector('main').appendChild(copy);

modal();
start();
};
function modal(){

const modal = document.getElementById("myModal");
const btn = document.getElementById("myBtn");
const span = document.getElementsByClassName("close")[0];
btn.onclick = function() {
  modal.style.display = "block";
}

span.onclick = function() {
  modal.style.display = "none";
}
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target === modal) {
    modal.style.display = "none";
  }
} 
};

function start(showList){

// TODO: Add event-listeners to filter and sort buttons
loadData();
};
function loadData(){
  fetch('https://petlatkea.dk/2021/hogwarts/students.json')
  .then(response => response.json()).then(handleData);

}
function handleData(data){
  prepareObjects(data);
}
function prepareObjects(student){
  const allStudents = student.map(handleObject);
  console.log(allStudents);

}

function handleObject(theStudent) {
const student = Object.create(Student);
const texts = theStudent.fullname.trim().split(' ');

  /* if (splittedName.length > 1){
  console.log(theStudent.fullname + 'Only one name')
}  */
  student.firstName = capitalizeString(texts [0]);
  student.midleName = capitalizeString(texts [1]);
  student.lastName =  capitalizeString(texts [2]);
 
  return student;

  };

  function capitalizeString(string) {
    return string.charAt(0).toUpperCase() + string.substring(1).toLowerCase()
    }




